"""
validation.py
Valida e normaliza o BUSINESS_JSON usando JSON Schema.
"""

import json
from jsonschema import validate, ValidationError


def validate_business_json(business_json: dict, schema_path: str) -> tuple[bool, str]:
    """
    Valida o JSON do negócio usando o JSON Schema.
    Retorna (bool, mensagem_de_erro_ou_ok).
    """
    try:
        with open(schema_path, "r", encoding="utf-8") as f:
            schema = json.load(f)
    except Exception as e:
        return False, f"Erro ao carregar schema: {e}"

    try:
        validate(instance=business_json, schema=schema)
        return True, "JSON válido!"
    except ValidationError as e:
        # e.message já traz uma mensagem mais amigável
        return False, str(e.message)


def _guess_default_for_schema(subschema: dict):
    """Escolhe um valor padrão baseado no tipo do campo."""
    t = subschema.get("type")
    if t == "array":
        return []
    if t == "object":
        return {}
    # string, number, boolean etc. -> placeholder genérico
    return "NEEDS_HUMAN_INPUT"


def normalize_business_json(instance: dict, schema: dict) -> dict:
    """
    Normaliza o BUSINESS_JSON de acordo com o schema:
    - Remove propriedades extras (quando additionalProperties = false)
    - Garante que campos 'required' existam (com placeholder)
    - Aplica recursivamente para objetos e arrays.
    """

    def _normalize(node, node_schema):
        if isinstance(node, dict):
            props = node_schema.get("properties", {})
            required = node_schema.get("required", [])

            # 1) remover propriedades extras
            if node_schema.get("additionalProperties") is False:
                keys_to_delete = [k for k in node.keys() if k not in props]
                for k in keys_to_delete:
                    del node[k]

            # 2) garantir required
            for key in required:
                if key not in node:
                    subschema = props.get(key, {})
                    node[key] = _guess_default_for_schema(subschema)

            # 3) recursão nas propriedades conhecidas
            for key, subschema in props.items():
                if key in node:
                    _normalize(node[key], subschema)

        elif isinstance(node, list):
            items_schema = node_schema.get("items")
            if items_schema:
                for item in node:
                    _normalize(item, items_schema)

        # tipos simples: nada a fazer

    _normalize(instance, schema)
    return instance
