"""
sales_agent.py
Responsável por usar o BUSINESS_JSON_VALIDATED
para responder mensagens de lead.
"""

import json
from utils.llm_client import LLMClient

class SalesAgent:
    def __init__(self, llm: LLMClient, system_prompt_template_path: str):
        self.llm = llm

        with open(system_prompt_template_path, "r", encoding="utf-8") as f:
            self.system_prompt_template = f.read()

    def load_business_json_into_prompt(self, business_json: dict) -> str:
        """
        Injeta o BUSINESS_JSON no system prompt do agente de vendas.
        """
        return self.system_prompt_template.replace(
            "{{BUSINESS_JSON}}",
            json.dumps(business_json, indent=2, ensure_ascii=False)
        )

    def run_turn(self, business_json: dict, user_message: str) -> dict:
        """
        Executa um turno de conversa com o lead.
        """
        system_prompt = self.load_business_json_into_prompt(business_json)

        reply_text = self.llm.generate(
            system_prompt=system_prompt,
            user_prompt=user_message
        )

        try:
            return json.loads(reply_text)
        except:
            raise ValueError("A LLM não retornou JSON estruturado de resposta.")
